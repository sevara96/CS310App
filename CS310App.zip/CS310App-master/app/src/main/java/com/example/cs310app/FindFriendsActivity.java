package com.example.cs310app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class FindFriendsActivity extends AppCompatActivity {


    private Button SearchButton;
    private EditText searchText;
    private FirebaseAuth mAuth;
    private RecyclerView ResultList;
    private DatabaseReference allUsersDatabaseRef;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_friends);
        mAuth = FirebaseAuth.getInstance();

        allUsersDatabaseRef = FirebaseDatabase.getInstance().getReference().child("Users");
        searchText = findViewById(R.id.inputField);
        SearchButton = findViewById(R.id.search_button);
        ResultList = findViewById(R.id.results);
        ResultList.setHasFixedSize(true);
        ResultList.setLayoutManager(new LinearLayoutManager(this));

        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.profile:
                        Intent intent = new Intent(FindFriendsActivity.this, ProfileActivity.class);
                        startActivity(intent);
                        break;
                    case R.id.sell:
                        intent = new Intent(FindFriendsActivity.this, SellActivity.class);
                        startActivity(intent);
                        break;
                    case R.id.buy:
                        intent = new Intent(FindFriendsActivity.this, MainActivity.class);
                        startActivity(intent);
                        break;
                    case R.id.friends:
                        intent = new Intent(FindFriendsActivity.this, FindFriendsActivity.class);
                        startActivity(intent);
                        break;

                    case R.id.logout:
                        mAuth.signOut();
                        Intent loginIntent = new Intent( FindFriendsActivity.this, LoginActivity.class);
                        loginIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(loginIntent);
                        finish();
                    default: return;
                }
            }
        });

        SearchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchBox = searchText.getText().toString();
                searchPeople(searchBox);
            }
        });



    }

    private  void searchPeople(String searchBox){

        Toast.makeText(this, "Searching...", Toast.LENGTH_LONG).show();
        Query searchPeopleQuery = allUsersDatabaseRef.orderByChild("fullName").startAt(searchBox).endAt(searchBox + "\uf8ff");



        FirebaseRecyclerAdapter<findFriends, FindFriendsViewHolder> fireBaseRecyclerAdapter
                = new FirebaseRecyclerAdapter<findFriends, FindFriendsViewHolder>(

                findFriends.class, R.layout.display_users,FindFriendsViewHolder.class,searchPeopleQuery)
        {
            @Override
            protected void populateViewHolder(FindFriendsViewHolder findFriendsViewHolder, findFriends model, final int position) {
                findFriendsViewHolder.setFullName(model.getFullName());
                //findFriendsViewHolder.setProfileImage(getApplicationContext(), model.getProfileImage());
                findFriendsViewHolder.mView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String user_ref_id = getRef(position).getKey();
                        Intent profileIntent = new Intent(FindFriendsActivity.this,PersonProfileActivity.class);
                        profileIntent.putExtra("user_ref_id", user_ref_id);
                        startActivity(profileIntent);
                    }
                });
            }
        };

        ResultList.setAdapter(fireBaseRecyclerAdapter);
    }

    public  static  class FindFriendsViewHolder extends RecyclerView.ViewHolder{

        View mView;
        public  FindFriendsViewHolder(View itemView){
            super(itemView);
            this.mView = itemView;
        }

//        public void setProfileImage(Context ctx, String profileImage) {
//            ImageView myImage = mView.findViewById(R.id.all_users_image);
//           // Picasso.with(ctx).load(ctx).load(profileImage).placeholder(R.drawble)
//
//        }

        public void setFullName(String fullName) {
            TextView myName = mView.findViewById(R.id.all_users_name);
            myName.setText(fullName);
            Log.d("name", myName.toString());


        }

    }
}
